chatMsg table for specific users
columns:id, message, sender (mavi), receiver (null),createdOn, modifiedOn, isDeleted 
