<!-- Bootsrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js" integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO" crossorigin="anonymous"></script>
<!-- SWUP -->
<!-- <script defer src="https://unpkg.com/swup@3"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/swup/3.0.5/Swup.umd.js" integrity="sha512-IaQgi2ZHv5GtkEvtfNvFCNqrcDUsxdcHIVIKPiExsqq1mBMW+0Bgg+MIiSlPX6oo4lW4e/NHkm8FQ31tNLrs6Q==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

